/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * Husk -- iOS dual-mapped JIT memory for QEMU's TCG.  See husk-ios-jit.h.
 *
 * Derived from AetherPS4-iOS's src/core/ios/ios_jit_allocator.cpp
 * (shadPS4 Emulator Project, GPL-2.0-or-later), ported C++ -> C.
 */

#include "husk-ios-jit.h"

#ifdef __APPLE__
#include <TargetConditionals.h>
#endif

#if defined(__APPLE__) && TARGET_OS_IPHONE

#include <errno.h>
#include <mach/mach.h>
#include <mach/vm_map.h>        /* vm_remap/vm_protect: mach_vm.h is absent from the iOS SDK */
#include <os/log.h>
#include <os/proc.h>
#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <mach/task.h>
#include <mach/task_info.h>
#include <libkern/OSCacheControl.h>
#include <sys/ucontext.h>   /* not <ucontext.h>: that one #errors without _XOPEN_SOURCE */
#include <unistd.h>
#include <fcntl.h>

/*
 * Provide pipe2 for iOS systems where libc does not export it.
 */
__attribute__((visibility("default")))
int pipe2(int fds[2], int flags)
{
    if (!fds) {
        errno = EFAULT;
        return -1;
    }
    if (pipe(fds) < 0) {
        return -1;
    }
    if (flags & O_CLOEXEC) {
        if (fcntl(fds[0], F_SETFD, FD_CLOEXEC) < 0 ||
            fcntl(fds[1], F_SETFD, FD_CLOEXEC) < 0) {
            int err = errno;
            close(fds[0]);
            close(fds[1]);
            errno = err;
            return -1;
        }
    }
    if (flags & O_NONBLOCK) {
        int f0 = fcntl(fds[0], F_GETFL);
        int f1 = fcntl(fds[1], F_GETFL);
        if (f0 < 0 || f1 < 0 ||
            fcntl(fds[0], F_SETFL, f0 | O_NONBLOCK) < 0 ||
            fcntl(fds[1], F_SETFL, f1 | O_NONBLOCK) < 0) {
            int err = errno;
            close(fds[0]);
            close(fds[1]);
            errno = err;
            return -1;
        }
    }
    return 0;
}

/* TCG's own W^X toggle. pthread_jit_write_protect_np() is marked unavailable in
 * the iOS SDK -- the symbol exists but the header refuses it -- so QEMU pokes
 * the APRR registers through the comm page instead. This file is compiled
 * inside QEMU's tcg/ directory, so the same header is the right one to use, and
 * using anything else would risk testing a different mechanism from the one the
 * emulator will actually run on. */
#include "tcg/tcg-apple-jit.h"

/* Maximum verbosity by default: this path is nearly impossible to debug after the
 * fact on device, and every line here is printed at most a handful of times per
 * session. Goes to os_log (visible in Console.app) and stderr both. */
static double husk_now_ms(void)
{
    static double base = 0;
    struct timeval tv;
    gettimeofday(&tv, NULL);
    double t = tv.tv_sec * 1000.0 + tv.tv_usec / 1000.0;
    if (base == 0) { base = t; }
    return t - base;
}

#define HUSK_LOG(fmt, ...)                                                     \
    do {                                                                       \
        os_log(OS_LOG_DEFAULT, "[husk-jit] " fmt, ##__VA_ARGS__);              \
        fprintf(stderr, "[%9.2fms][husk-jit] " fmt "\n",                       \
                husk_now_ms(), ##__VA_ARGS__);                                 \
        fflush(stderr);                                                        \
    } while (0)

/* ------------------------------------------------------------------ symbols */
/*
 * The trap sequences live in husk-brk.S, compiled straight into this binary.
 * Husk deliberately does NOT link or dlopen Stossy11's BreakpointJIT.framework:
 * it has no stated license, and any embedded framework carrying entitlements is
 * rejected by AMFI at launch on sideloaded builds. See husk-brk.S for the
 * verification that our encoding matches theirs exactly.
 */
extern void    *husk_brk_get_jit_mapping(void *addr, size_t len);
extern void     husk_brk_jit_detach(void);
extern uint64_t husk_brk_probe(void);

/*
 * StikDebug answers brk #0x69 by writing a constant into x0. Two encodings are
 * seen in the wild:
 *
 *   0xE0000069  -- the value as written in the script
 *   0x690000E0  -- that value byte-reversed, which is what universal.js actually
 *                  produces: it sends the gdb-remote packet `P0=E0000069`, but P
 *                  takes the register in TARGET byte order, and ARM64 is little
 *                  endian. It also supplies only 4 bytes for an 8-byte register,
 *                  so the upper half keeps whatever poison was there (0xcccccccc
 *                  observed on iPhone18,1 / iOS 27).
 *
 * Matching on an exact value is therefore the wrong test. What actually
 * distinguishes "serviced" from "not serviced" is far simpler: when StikDebug is
 * absent, our own SIGTRAP handler steps over the brk and sets x0 to exactly 0.
 * So any non-zero answer means something serviced the trap.
 */
#define HUSK_PROBE_MAGIC    0xE0000069ull
#define HUSK_PROBE_MAGIC_LE 0x690000E0ull

static atomic_bool           g_jit_available;
static atomic_uint_least64_t g_alloc_counter;

/* ------------------------------------------------------- unserviced-trap guard */
/*
 * Set for exactly the duration of the BreakGetJITMapping call. If StikDebug is
 * not there to service the brk, the trap is a real SIGTRAP that would otherwise
 * kill the process outright -- there is no "call returned an error" to recover
 * from. The handler below turns that into a NULL return, which the allocation
 * path already handles.
 */
static _Thread_local bool g_expecting_jit_trap;

static struct sigaction g_prev_sigtrap;
static struct sigaction g_prev_sigbus;

static void husk_trap_handler(int sig, siginfo_t *info, void *ctx)
{
    (void)info;
    if (g_expecting_jit_trap && ctx != NULL) {
        ucontext_t *uc = (ucontext_t *)ctx;
        /* Step over the brk and report failure in x0, exactly as the
         * StikDebug-serviced path would have written a result there. */
        uc->uc_mcontext->__ss.__pc += 4;
        uc->uc_mcontext->__ss.__x[0] = 0;
        return;
    }

    /* Not ours: restore and re-raise so a genuine breakpoint or bus error is
     * not silently swallowed. */
    struct sigaction *prev = (sig == SIGTRAP) ? &g_prev_sigtrap : &g_prev_sigbus;
    sigaction(sig, prev, NULL);
    raise(sig);
}

void husk_ios_jit_install_trap_handler(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = husk_trap_handler;
    sigemptyset(&sa.sa_mask);

    if (sigaction(SIGTRAP, &sa, &g_prev_sigtrap) != 0) {
        HUSK_LOG("sigaction(SIGTRAP) failed: %s", strerror(errno));
    }
    if (sigaction(SIGBUS, &sa, &g_prev_sigbus) != 0) {
        HUSK_LOG("sigaction(SIGBUS) failed: %s", strerror(errno));
    }
    HUSK_LOG("trap guard installed (SIGTRAP, SIGBUS)");
}

/* ---------------------------------------------------------------- footprint */
/*
 * phys_footprint is the figure jetsam judges us on, so it is the one worth
 * logging around every large allocation. An iOS app with the
 * increased-memory-limit entitlement still dies silently when this crosses the
 * device's cap, and a silent kill with no crash log is otherwise very hard to
 * tell apart from any other sudden death.
 */
void husk_ios_jit_log_footprint(const char *tag)
{
    task_vm_info_data_t info;
    mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
    if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &count)
        != KERN_SUCCESS) {
        HUSK_LOG("footprint[%s]: task_info failed", tag ? tag : "");
        return;
    }
    /*
     * os_proc_available_memory() is the number that actually matters: how much
     * more this process may allocate before jetsam kills it. phys_footprint alone
     * says how much we have used but not how close to the edge that is, and the
     * limit varies by device and by whether the increased-memory-limit entitlement
     * is honoured. A jetsam kill is a SIGKILL -- no handler runs and the log simply
     * stops -- so the only way to see it coming is to watch this fall.
     */
    size_t avail = os_proc_available_memory();

    HUSK_LOG("footprint[%s]: phys=%.1f MiB  resident=%.1f MiB  "
             "available-before-jetsam=%.1f MiB",
             tag ? tag : "",
             info.phys_footprint / (1024.0 * 1024.0),
             info.resident_size  / (1024.0 * 1024.0),
             avail / (1024.0 * 1024.0));
}

size_t husk_ios_available_memory(void)
{
    return os_proc_available_memory();
}

/* ---------------------------------------------------------------- self-test */
/*
 * The decisive check. StikDebug can hand back an address, and vm_remap can
 * succeed, while the pages were never actually prepared -- `_M,rx` allocating
 * without prepare_memory_region walking each page looks identical from here.
 * In that case nothing goes wrong until TCG branches into generated code, and
 * the app dies somewhere deep in the emulator with no useful context.
 *
 * So: write a two-instruction function through the RW alias, then CALL it
 * through the RX alias. If JIT works at all, this returns 42.
 */
static bool husk_jit_selftest(const HuskDualMapping *m)
{
    /* movz w0, #42  ;  ret */
    static const uint32_t kCode[2] = { 0x52800540u, 0xD65F03C0u };

    if (m->rw_addr == NULL || m->rx_addr == NULL) {
        return false;
    }

    HUSK_LOG("selftest: writing %zu bytes through RW alias %p", sizeof(kCode),
             (void *)m->rw_addr);
    memcpy(m->rw_addr, kCode, sizeof(kCode));

    /* Flush the write through to the RX view before executing it. */
    sys_icache_invalidate(m->rx_addr, sizeof(kCode));
    HUSK_LOG("selftest: icache invalidated on RX alias %p", (void *)m->rx_addr);

    /* Read back through RX to confirm the two aliases really share pages. */
    uint32_t readback[2];
    memcpy(readback, m->rx_addr, sizeof(readback));
    if (readback[0] != kCode[0] || readback[1] != kCode[1]) {
        HUSK_LOG("selftest: FAIL -- RX alias does not reflect RW writes "
                 "(read 0x%08x 0x%08x, expected 0x%08x 0x%08x). The two mappings "
                 "are not backed by the same pages.",
                 readback[0], readback[1], kCode[0], kCode[1]);
        return false;
    }
    HUSK_LOG("selftest: RX alias reflects RW writes (0x%08x 0x%08x) -- aliasing OK",
             readback[0], readback[1]);

    HUSK_LOG("selftest: CALLING generated code at %p ...", (void *)m->rx_addr);
    int (*fn)(void) = (int (*)(void))(void *)m->rx_addr;
    int result = fn();

    if (result != 42) {
        HUSK_LOG("selftest: FAIL -- generated code ran but returned %d, expected 42",
                 result);
        return false;
    }
    HUSK_LOG("selftest: PASS -- executed generated code from the RX alias, got 42. "
             "JIT is genuinely live.");
    return true;
}


/* ------------------------------------------------------------ self-granted */
/*
 * Executable memory without a trap servicer. This is how TrollStore and jailbreaks give an app JIT:
 *
 *   - TrollStore apps cannot use banned entitlements such as dynamic-codesigning on affected systems
 *     (see https://github.com/opa334/TrollStore#banned-entitlements), so they cannot rely on the normal entitlement-based JIT path.
 *     TrollStore's "Open with JIT" / enable-jit instead attaches with ptrace and detaches, leaving the process debugged.
 *   - Dopamine similarly allows invalid executable pages for jailbreak processes, while its csops hook may hide CS_DEBUGGED
 *     unless "Allow JIT in Apps" is enabled.
 *   - Debugger-based JIT methods such as AltJIT, SideJITServer and StikDebug use the same general mechanism on affected iOS versions.
 *
 * Under W^X restrictions, memory cannot be simultaneously writable and executable through the same mapping. The fallback path:
 *   1. Allocates backing memory with RWX maximum protection.
 *   2. Creates a separate RW alias with vm_remap() for code generation.
 *   3. Demotes the executable mapping to RX with vm_protect().
 * This gives separate RW and RX views of the same backing pages.
 */
/* csops straight to the kernel: Dopamine hooks the libc function to hide CS_DEBUGGED (systemhook's csops_hook). */
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
static bool husk_kernel_debugged(void)
{
    uint32_t flags = 0;
    return syscall(169 /* SYS_csops */, getpid(), 0 /* CS_OPS_STATUS */, &flags, sizeof(flags)) == 0 && (flags & 0x10000000u);
}
#pragma clang diagnostic pop

static bool husk_page_is_executable(void *p);

static sigjmp_buf g_self_jump;
static volatile sig_atomic_t g_self_running;

static void husk_self_fault(int sig)
{
    if (g_self_running) siglongjmp(g_self_jump, 1);
    signal(sig, SIG_DFL);
    raise(sig);
}

static bool husk_self_selftest(uint8_t *rx, uint8_t *rw)
{
    /* movz w0, #0x5a5a ; ret */
    static const uint32_t code[2] = { 0x528B4B40u, 0xD65F03C0u };
    if (!husk_page_is_executable(rx)) return false;
    struct sigaction sa, ob, os, oi;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = husk_self_fault;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGBUS, &sa, &ob); sigaction(SIGSEGV, &sa, &os); sigaction(SIGILL, &sa, &oi);
    bool ok = false;
    g_self_running = 1;
    if (sigsetjmp(g_self_jump, 1) == 0) {
        memcpy(rw, code, sizeof(code));
        sys_icache_invalidate(rx, sizeof(code));
        ok = ((int (*)(void))(void *)rx)() == 0x5a5a;
    }
    g_self_running = 0;
    sigaction(SIGBUS, &ob, NULL); sigaction(SIGSEGV, &os, NULL); sigaction(SIGILL, &oi, NULL);
    return ok;
}

/* A writable alias of [rx, rx + size), placed right after it if possible and within 2 GiB either way. */
static uint8_t *husk_rw_alias(uint8_t *rx, size_t size, bool fixed)
{
    vm_address_t alias = (vm_address_t)(rx + size);
    vm_prot_t cur, max;
    kern_return_t kr = vm_remap(mach_task_self(), &alias, size, 0,
                                fixed ? (VM_FLAGS_FIXED | VM_FLAGS_OVERWRITE) : VM_FLAGS_ANYWHERE,
                                mach_task_self(), (vm_address_t)rx, FALSE, &cur, &max, VM_INHERIT_NONE);
    if (kr != KERN_SUCCESS) {
        HUSK_LOG("self: vm_remap failed: %d (%s)", (int)kr, mach_error_string(kr));
        return NULL;
    }
    long long dist = (long long)alias - (long long)(uintptr_t)rx;
    if (dist > (2LL << 30) || dist < -(2LL << 30) ||
        vm_protect(mach_task_self(), alias, size, FALSE, VM_PROT_READ | VM_PROT_WRITE) != KERN_SUCCESS) {
        HUSK_LOG("self: writable alias unusable (distance %lld)", dist);
        vm_deallocate(mach_task_self(), alias, size);
        return NULL;
    }
    return (uint8_t *)alias;
}

/* How the held region was made, for Settings: NULL until it is, then "MAP_JIT" or "plain". */
static const char *volatile g_self_route;

const char *husk_ios_jit_self_route(void) { return g_self_route; }

static HuskDualMapping husk_self_dual_mapping(size_t bytes)
{
    HuskDualMapping none = { NULL, NULL, 0 };
    if (__builtin_available(iOS 26.0, *)) {
        HUSK_LOG("self: iOS 26 enforces TXM; only a debugger can grant executable memory here");
        return none;
    }
    size_t size = (bytes + 0x3fff) & ~(size_t)0x3fff;

    /* 1. MAP_JIT: requires dynamic-codesigning. Refused with EPERM elsewhere, harmlessly. */
    uint8_t *rx = mmap(NULL, size, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANON | MAP_JIT, -1, 0);
    if (rx == MAP_FAILED) {
        HUSK_LOG("self: MAP_JIT refused (%s)", strerror(errno));
    } else {
        uint8_t *rw = husk_rw_alias(rx, size, false);
        if (rw && vm_protect(mach_task_self(), (vm_address_t)rx, size, FALSE, VM_PROT_READ | VM_PROT_EXECUTE) == KERN_SUCCESS && husk_self_selftest(rx, rw)) {
            HuskDualMapping m = { rw, rx, size };
            atomic_store(&g_jit_available, true);
            g_self_route = "MAP_JIT";
            HUSK_LOG("self: PASS -- %zu MiB from MAP_JIT (dynamic-codesigning), rx=%p rw=%p", size >> 20, (void *)rx, (void *)rw);
            return m;
        }
        HUSK_LOG("self: MAP_JIT region did not pass its test");
        if (rw) vm_deallocate(mach_task_self(), (vm_address_t)rw, size);
        munmap(rx, size);
    }

    /* 2. Plain memory made executable: only where invalid pages are known to be allowed. */
    bool debugged = husk_kernel_debugged();
    bool jailbroken = access("/var/jb", F_OK) == 0;
    if (!debugged && !jailbroken) {
        HUSK_LOG("self: not marked as debugged and not jailbroken; nothing else is safe to try");
        return none;
    }
    uint8_t *base = mmap(NULL, size * 2, PROT_NONE, MAP_PRIVATE | MAP_ANON, -1, 0);
    if (base == MAP_FAILED) {
        HUSK_LOG("self: could not reserve %zu MiB: %s", (size * 2) >> 20, strerror(errno));
        return none;
    }
    /* Two layouts: writable+executable asked for and then made read+execute (the kernel drops execute from the first), or
     * read+execute from the start, as UTM and Dolphin map it. Each step that fails says so (#127: an A15 on iOS 18 with
     * CS_DEBUGGED set failed one of them without saying which). */
    static const int first_prot[2] = { PROT_READ | PROT_WRITE | PROT_EXEC, PROT_READ | PROT_EXEC };
    static const char *const layout[2] = { "rwx then rx", "rx" };
    for (int i = 0; i < 2; i++) {
        rx = mmap(base, size, first_prot[i], MAP_FIXED | MAP_PRIVATE | MAP_ANON, -1, 0);
        if (rx == MAP_FAILED) { HUSK_LOG("self: plain (%s): mmap failed: %s", layout[i], strerror(errno)); continue; }
        uint8_t *rw = husk_rw_alias(rx, size, true);
        if (!rw) { HUSK_LOG("self: plain (%s): no writable alias", layout[i]); continue; }
        kern_return_t kr = vm_protect(mach_task_self(), (vm_address_t)rx, size, FALSE, VM_PROT_READ | VM_PROT_EXECUTE);
        if (kr != KERN_SUCCESS) {
            HUSK_LOG("self: plain (%s): vm_protect r-x failed: %d (%s)", layout[i], (int)kr, mach_error_string(kr));
            continue;
        }
        if (!husk_page_is_executable(rx)) { HUSK_LOG("self: plain (%s): the kernel did not keep execute on the page", layout[i]); continue; }
        if (husk_self_selftest(rx, rw)) {
            HuskDualMapping m = { rw, rx, size };
            atomic_store(&g_jit_available, true);
            g_self_route = "plain";
            HUSK_LOG("self: PASS -- %zu MiB of plain memory (%s, %s), rx=%p rw=%p", size >> 20,
                     debugged ? "process is debugged" : "jailbreak allows invalid pages", layout[i], (void *)rx, (void *)rw);
            return m;
        }
        HUSK_LOG("self: plain (%s): code written through the alias faulted or returned the wrong value", layout[i]);
    }
    HUSK_LOG("self: plain memory did not execute (%s)", debugged ? "debugged" : "jailbroken");
    munmap(base, size * 2);
    return none;
}

/* ------------------------------------------------------------- allocation */

/*
 * Husk: take the JIT region early, before anything slow happens.
 *
 * StikDebug does not stay attached indefinitely. A first run downloads about
 * 1.1 GB of guest image before QEMU starts, and by the time qemu_init() reached
 * alloc_code_gen_buffer the debugger had let go:
 *
 *   StikDebug is NOT servicing traps -- probe returned 0
 *   could not obtain 268435456 bytes of JIT memory
 *
 * Nothing can recover from that in-process: without a debugger there is no way
 * to get executable memory, and asking again later is exactly what does not
 * work. So the region is claimed at app launch, while the attachment is fresh,
 * and held until QEMU asks for it.
 */
static HuskDualMapping husk_ios_jit_allocate_real(size_t bytes);

static HuskDualMapping husk_prewarmed;
static bool husk_prewarm_done;

HUSK_EXPORT bool husk_ios_jit_prewarm(size_t bytes)
{
    if (husk_prewarm_done) {
        return husk_prewarmed.rw_addr != NULL;
    }
    husk_prewarm_done = true;
    husk_prewarmed = husk_ios_jit_allocate_real(bytes);
    fprintf(stderr, "[husk-jit] prewarm %s: %zu bytes\n",
            husk_prewarmed.rw_addr ? "OK" : "FAILED", bytes);
    return husk_prewarmed.rw_addr != NULL;
}

/*
 * Before iOS 26, without a trap: the region made by this process itself (MAP_JIT, or plain memory where the process is marked as
 * debugged or the jailbreak allows invalid pages). For TrollStore's and Dopamine's attach, which answers no brk (#148).
 */
HUSK_EXPORT bool husk_ios_jit_prewarm_self(size_t bytes)
{
    if (husk_prewarmed.rw_addr) return true;
    HuskDualMapping m = husk_self_dual_mapping(bytes);
    if (!m.rw_addr) return false;
    husk_prewarmed = m;
    husk_prewarm_done = true;
    fprintf(stderr, "[husk-jit] prewarm (self, %s) OK: %zu bytes\n", g_self_route ? g_self_route : "?", m.size);
    return true;
}

/* The held region, for the native runtime (translation-layer/husk-tl-load.c looks this up by name). */
HUSK_EXPORT HuskDualMapping *husk_ios_jit_get_mapping(void)
{
    return husk_prewarmed.rw_addr ? &husk_prewarmed : NULL;
}

/*
 * One region, two users. The native runtime writes from the bottom of it and QEMU's TCG takes the top, so an Android app
 * started while Android itself runs (or Android started after one) does not write its code over the other's: that ended in
 * SIGILL inside cpu_tb_exec. Whichever comes second and does not fit gets a failure instead.
 */
static pthread_mutex_t husk_share_lock = PTHREAD_MUTEX_INITIALIZER;
static size_t husk_runtime_high;   /* bytes from the bottom the native runtime has taken */
static size_t husk_qemu_top;       /* bytes at the top QEMU holds */

HUSK_EXPORT bool husk_ios_jit_reserve_bottom(size_t end)
{
    pthread_mutex_lock(&husk_share_lock);
    bool ok = end <= husk_prewarmed.size - husk_qemu_top;
    if (ok && end > husk_runtime_high) husk_runtime_high = end;
    pthread_mutex_unlock(&husk_share_lock);
    if (!ok) {
        fprintf(stderr, "[husk-jit] the native runtime wants %zu MiB of the JIT region, but QEMU holds its top %zu MiB\n",
                end >> 20, husk_qemu_top >> 20);
    }
    return ok;
}

HuskDualMapping husk_ios_jit_allocate(size_t bytes)
{
    /*
     * Hand back the prewarmed region when it is big enough. QEMU asks for
     * exactly tb-size, which is what prewarm was given, so this is the normal
     * path -- the fallback below only runs if prewarm never happened.
     */
    if (husk_prewarmed.rw_addr && husk_prewarmed.size >= bytes) {
        size_t off = (husk_prewarmed.size - bytes) & ~(size_t)0x3FFF;
        pthread_mutex_lock(&husk_share_lock);
        bool fits = husk_runtime_high <= off;
        if (fits) husk_qemu_top = husk_prewarmed.size - off;
        pthread_mutex_unlock(&husk_share_lock);
        if (!fits) {
            fprintf(stderr, "[husk-jit] the native runtime already uses %zu MiB of the %zu MiB region; no room for %zu MiB of TCG\n",
                    husk_runtime_high >> 20, husk_prewarmed.size >> 20, bytes >> 20);
            HuskDualMapping none = { NULL, NULL, 0 };
            return none;
        }
        fprintf(stderr, "[husk-jit] using the top %zu MiB of the prewarmed region (%zu MiB)\n",
                (husk_prewarmed.size - off) >> 20, husk_prewarmed.size >> 20);
        HuskDualMapping top = { husk_prewarmed.rw_addr + off, husk_prewarmed.rx_addr + off, husk_prewarmed.size - off };
        return top;
    }
    /*
     * No second trap after a prewarm already went unanswered.
     * Inside qemu_init there is even less chance StikDebug is listening, and a
     * debugger that is attached but not answering keeps the whole process
     * stopped on the brk, so the app freezes. Failing here lets region.c
     * fall back to MAP_JIT, or lets qemu_init report the error.
     */
    if (husk_prewarm_done) {
        fprintf(stderr, "[husk-jit] prewarm failed earlier; not trapping again\n");
        HuskDualMapping none = { NULL, NULL, 0 };
        return none;
    }
    return husk_ios_jit_allocate_real(bytes);
}

static HuskDualMapping husk_ios_jit_allocate_real(size_t bytes)
{
    HuskDualMapping region = { NULL, NULL, 0 };
    uint64_t n = atomic_fetch_add(&g_alloc_counter, 1) + 1;

    /* Cheap attach probe: brk #0x69 is answered with a constant when StikDebug
     * is live, and swallowed by our trap handler as 0 when it is not. Doing this
     * first turns "no debugger" into a clean diagnostic instead of three slow
     * retries of the real request. */
    g_expecting_jit_trap = true;
    uint64_t probe = husk_brk_probe();
    g_expecting_jit_trap = false;
    if (probe == 0) {
        HUSK_LOG("#%llu: StikDebug is NOT servicing traps -- probe returned 0, which "
                 "is our own SIGTRAP handler stepping over an unanswered brk. "
                 "Trying to make %zu bytes without it.",
                 (unsigned long long)n, bytes);
        return husk_self_dual_mapping(bytes);
    }

    uint32_t probe_lo = (uint32_t)probe;
    if (probe_lo == (uint32_t)HUSK_PROBE_MAGIC ||
        probe_lo == (uint32_t)HUSK_PROBE_MAGIC_LE) {
        HUSK_LOG("#%llu: StikDebug attach probe OK (0x%llx)",
                 (unsigned long long)n, (unsigned long long)probe);
    } else {
        /* Serviced, but by something that answers differently. Proceed -- the
         * allocation itself is the real test -- and record the value so an
         * unfamiliar StikDebug build is identifiable from the log alone. */
        HUSK_LOG("#%llu: trap was serviced but the answer is unrecognised (0x%llx). "
                 "Continuing anyway; the allocation below is the real test.",
                 (unsigned long long)n, (unsigned long long)probe);
    }

    /*
     * Ask for a FRESH region (x0 == 0) so StikDebug allocates it with
     * debugserver `_M<size>,rx` and then walks every 16 KiB page with
     * `M<addr>,1:69`. Requesting a fresh region is the only branch that gets
     * those pages prepared; handing in an address we allocated ourselves does not.
     *
     * StikDebug can be momentarily unresponsive (busy, or briefly suspended by
     * iOS) rather than permanently gone, and the two are indistinguishable from
     * here, so retry a few times before giving up.
     */
    enum { kMaxAttempts = 3 };
    void *rx = NULL;
    for (int attempt = 1; attempt <= kMaxAttempts; attempt++) {
        HUSK_LOG("#%llu: requesting execute-capable region, size=%zu (%.1f MiB), "
                 "attempt %d/%d",
                 (unsigned long long)n, bytes, (double)bytes / (1024.0 * 1024.0),
                 attempt, kMaxAttempts);

        g_expecting_jit_trap = true;
        rx = husk_brk_get_jit_mapping(NULL, bytes);
        g_expecting_jit_trap = false;

        HUSK_LOG("#%llu: BreakGetJITMapping returned %p", (unsigned long long)n, rx);
        if (rx != NULL) {
            break;
        }
        if (attempt < kMaxAttempts) {
            usleep(50 * 1000);
        }
    }

    if (rx == NULL) {
        HUSK_LOG("#%llu: FAILED after %d attempts. StikDebug must be attached with "
                 "the Universal JIT script BEFORE the guest is started.",
                 (unsigned long long)n, kMaxAttempts);
        return region;
    }

    /* Writable alias of the same physical pages. Purely local -- no debugger
     * involvement, and therefore still available after detach. */
    /* Near the executable view: the translation layer's loader retargets code at this alias with adrp, which reaches +-4 GiB,
     * and a kernel left to choose (VM_FLAGS_ANYWHERE) can put it hundreds of GiB away (seen on iOS 27). Free addresses after
     * the region, then before it, in 16 MiB steps out to 2 GiB; anywhere only if none is free. */
    vm_address_t rw = 0;
    vm_prot_t cur_prot = VM_PROT_NONE, max_prot = VM_PROT_NONE;
    kern_return_t kr = KERN_NO_SPACE;
    const uintptr_t step = 16u << 20, reach = (uintptr_t)2 << 30;
    for (uintptr_t off = 0; off <= reach && kr != KERN_SUCCESS; off += step) {
        for (int side = 0; side < 2 && kr != KERN_SUCCESS; side++) {
            uintptr_t want = side == 0 ? (uintptr_t)rx + bytes + off : (uintptr_t)rx - bytes - off;
            if (side == 1 && (uintptr_t)rx < bytes + off + step) continue;
            rw = (vm_address_t)want;
            kr = vm_remap(mach_task_self(), &rw, (vm_size_t)bytes, /*mask=*/0, VM_FLAGS_FIXED,
                          mach_task_self(), (vm_address_t)rx, /*copy=*/FALSE, &cur_prot, &max_prot, VM_INHERIT_NONE);
        }
    }
    if (kr != KERN_SUCCESS) {
        HUSK_LOG("#%llu: no free space within 2 GiB of rx=%p for the writable view: placing it anywhere", (unsigned long long)n, rx);
        rw = 0;
        kr = vm_remap(mach_task_self(), &rw, (vm_size_t)bytes,
                      /*mask=*/0, VM_FLAGS_ANYWHERE,
                      mach_task_self(), (vm_address_t)rx,
                      /*copy=*/FALSE, &cur_prot, &max_prot,
                      VM_INHERIT_NONE);
    }
    if (kr != KERN_SUCCESS) {
        HUSK_LOG("#%llu: vm_remap failed for rx=%p size=%zu: %d (%s)",
                 (unsigned long long)n, rx, bytes, (int)kr, mach_error_string(kr));
        return region;
    }

    kr = vm_protect(mach_task_self(), rw, (vm_size_t)bytes, /*set_maximum=*/FALSE,
                    VM_PROT_READ | VM_PROT_WRITE);
    if (kr != KERN_SUCCESS) {
        HUSK_LOG("#%llu: vm_protect(RW) failed for rw=%p size=%zu: %d (%s)",
                 (unsigned long long)n, (void *)rw, bytes, (int)kr,
                 mach_error_string(kr));
        vm_deallocate(mach_task_self(), rw, (vm_size_t)bytes);
        return region;
    }

    region.rw_addr = (uint8_t *)rw;
    region.rx_addr = (uint8_t *)rx;
    region.size    = bytes;
    atomic_store(&g_jit_available, true);

    HUSK_LOG("#%llu: dual mapping established: rw=%p rx=%p size=%zu diff=%+lld",
             (unsigned long long)n, (void *)region.rw_addr, (void *)region.rx_addr,
             region.size, (long long)(region.rx_addr - region.rw_addr));
    husk_ios_jit_log_footprint("after-jit-alloc");

    if (!husk_jit_selftest(&region)) {
        HUSK_LOG("#%llu: SELFTEST FAILED -- the region is not usable as JIT memory. "
                 "Refusing to hand it to TCG; QEMU would crash on its first "
                 "generated block instead of failing here.",
                 (unsigned long long)n);
        husk_ios_jit_release(&region);
        return region;
    }

    return region;
}

void husk_ios_jit_release(HuskDualMapping *m)
{
    if (m == NULL) {
        return;
    }
    if (m->rw_addr != NULL) {
        vm_deallocate(mach_task_self(), (vm_address_t)m->rw_addr, (vm_size_t)m->size);
        m->rw_addr = NULL;
    }
    if (m->rx_addr != NULL) {
        vm_deallocate(mach_task_self(), (vm_address_t)m->rx_addr, (vm_size_t)m->size);
        m->rx_addr = NULL;
    }
    m->size = 0;
}

void husk_ios_jit_detach(void)
{
    HUSK_LOG("detaching debugger; RX mappings persist after this");
    g_expecting_jit_trap = true;
    husk_brk_jit_detach();
    g_expecting_jit_trap = false;
    HUSK_LOG("debugger detached");
}

bool husk_ios_jit_is_available(void)
{
    return atomic_load(&g_jit_available);
}

/* ------------------------------------------------------------- MAP_JIT probe */
/*
 * Ask the kernel what it actually granted, before branching into it.
 *
 * The signal guard below catches a fault, but not every refusal arrives as a
 * signal: a device that enforces TXM can answer an attempt to execute
 * unblessed memory by killing the process outright, and no handler survives
 * that. So the dangerous instruction is only reached once the kernel has said
 * the page carries execute permission -- on a device where it does not, this
 * returns false without ever branching there.
 */
static bool husk_page_is_executable(void *p)
{
    vm_address_t addr = (vm_address_t)p;
    vm_size_t size = 0;
    natural_t depth = 0;
    vm_region_submap_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;

    kern_return_t kr = vm_region_recurse_64(mach_task_self(), &addr, &size, &depth,
                                            (vm_region_recurse_info_t)&info, &count);
    if (kr != KERN_SUCCESS) {
        HUSK_LOG("MAP_JIT probe: vm_region_recurse_64 failed: %s", mach_error_string(kr));
        return false;
    }
    HUSK_LOG("MAP_JIT probe: kernel granted protection 0x%x (execute %s)",
             (unsigned)info.protection,
             (info.protection & VM_PROT_EXECUTE) ? "yes" : "NO");
    return (info.protection & VM_PROT_EXECUTE) != 0;
}

static sigjmp_buf g_probe_jump;
static volatile sig_atomic_t g_probe_running;

static void husk_probe_handler(int sig)
{
    if (g_probe_running) {
        siglongjmp(g_probe_jump, 1);
    }
    /* Not ours -- a fault on another thread inside the probe's brief window.
     * Let it crash the way it would have without us. */
    signal(sig, SIG_DFL);
    raise(sig);
}

/*
 * Can this process execute memory it wrote itself?
 *
 * There are two ways to get executable memory on iOS, and Husk only ever tried
 * one of them properly. The dual mapping above needs a debugger that services
 * brk traps; the other route is a plain MAP_JIT mapping, which the kernel
 * honours for any process with CS_DEBUGGED set and which is what QEMU falls
 * back to on its own. Which of the two is available depends on the device, the
 * iOS version and which tool enabled JIT, in ways that are not worth
 * predicting -- so this stops predicting and asks.
 *
 * The execution itself is guarded twice: the kernel is asked whether the page
 * carries execute permission before anything branches into it, and a signal
 * guard catches the fault if it turns out not to. A probe meant to answer a
 * question must not become the thing that killed the app.
 */
bool husk_ios_jit_mapjit_works(void)
{
    static atomic_int cached;   /* 0 unknown, 1 yes, -1 no */
    int known = atomic_load(&cached);
    if (known != 0) {
        return known > 0;
    }

    /* movz w0, #0x1234  ;  ret */
    static const uint32_t kCode[2] = { 0x52824680u, 0xD65F03C0u };
    const size_t len = 16 * 1024;   /* one iOS page */
    bool ok = false;

    void *p = mmap(NULL, len, PROT_READ | PROT_WRITE | PROT_EXEC,
                   MAP_PRIVATE | MAP_ANON | MAP_JIT, -1, 0);
    if (p == MAP_FAILED) {
        HUSK_LOG("MAP_JIT probe: mmap refused (%s) -- no executable memory this "
                 "way; a trap servicer is the only route on this device",
                 strerror(errno));
        atomic_store(&cached, -1);
        return false;
    }

    if (!husk_page_is_executable(p)) {
        HUSK_LOG("MAP_JIT probe: the mapping came back without execute permission "
                 "-- a trap servicer is the only route on this device");
        munmap(p, len);
        atomic_store(&cached, -1);
        return false;
    }

    struct sigaction sa, prev_bus, prev_segv, prev_ill;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = husk_probe_handler;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGBUS, &sa, &prev_bus);
    sigaction(SIGSEGV, &sa, &prev_segv);
    sigaction(SIGILL, &sa, &prev_ill);

    g_probe_running = 1;
    if (sigsetjmp(g_probe_jump, 1) == 0) {
        // On a device with APRR the page is write-protected until asked
        // otherwise; on one without, it is plain RWX and these are no-ops.
        // The guard covers the write as well as the call, so a page that
        // refuses either fails the probe rather than the process.
        if (jit_write_protect_supported()) { jit_write_protect(0); }
        memcpy(p, kCode, sizeof(kCode));
        if (jit_write_protect_supported()) { jit_write_protect(1); }
        sys_icache_invalidate(p, sizeof(kCode));

        int (*fn)(void) = (int (*)(void))p;
        ok = (fn() == 0x1234);
    } else {
        HUSK_LOG("MAP_JIT probe: faulted while executing the page -- the mapping "
                 "was granted but is not executable");
    }
    g_probe_running = 0;

    sigaction(SIGBUS, &prev_bus, NULL);
    sigaction(SIGSEGV, &prev_segv, NULL);
    sigaction(SIGILL, &prev_ill, NULL);
    munmap(p, len);

    HUSK_LOG("MAP_JIT probe: %s", ok
             ? "PASS -- this process can execute memory it wrote, so QEMU can "
               "run on MAP_JIT even without a trap servicer"
             : "FAIL -- MAP_JIT memory is not executable here");
    atomic_store(&cached, ok ? 1 : -1);
    return ok;
}

#else /* !iOS: keep the symbols so host builds and tests link */

void husk_ios_jit_install_trap_handler(void) {}
static HuskDualMapping husk_ios_jit_allocate_real(size_t bytes)
{
    (void)bytes;
    HuskDualMapping m = { NULL, NULL, 0 };
    return m;
}
HuskDualMapping husk_ios_jit_allocate(size_t bytes)
{
    return husk_ios_jit_allocate_real(bytes);
}
bool husk_ios_jit_prewarm(size_t bytes) { (void)bytes; return false; }
bool husk_ios_jit_prewarm_self(size_t bytes) { (void)bytes; return false; }
bool husk_ios_jit_reserve_bottom(size_t end) { (void)end; return true; }
void husk_ios_jit_release(HuskDualMapping *m) { (void)m; }
void husk_ios_jit_detach(void) {}
bool husk_ios_jit_is_available(void) { return false; }
bool husk_ios_jit_mapjit_works(void) { return false; }
const char *husk_ios_jit_self_route(void) { return 0; }
void husk_ios_jit_log_footprint(const char *tag) { (void)tag; }
size_t husk_ios_available_memory(void) { return 0; }

#endif
